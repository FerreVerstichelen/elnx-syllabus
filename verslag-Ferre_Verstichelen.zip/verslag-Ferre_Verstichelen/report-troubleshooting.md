# Enterprise Linux Laboverslag - Troubleshooting

- Student: Ferre Verstichelen
- Klasgroep: TIN-TI/3B1 (Gent)

## Instructies

- Schrijf een gedetailleerd verslag verderop in dit document
- Gebruik correcte Markdown! Gebruik waar mogelijk "fenced code blocks" ipv screenshots voor commando's en hun uitvoer, transcript van de terminal, ...
- De verschillende fasen in de bottom-up troubleshooting-strategie worden besproken in een aparte subsectie (hoofding van niveau 3, starten met `###`) met de naam van de fase als titel.
- Elke stap is in detail beschreven:
    - Wat je precies test en het verwachte resultaat
    - Het commando (incl. opties en argumenten) waarmee je de test uitvoert, of het absolute pad naar het te controleren configuratiebestand
    - Als de uitvoer van de test verschilt van wat je verwacht, wat is de oorzaak?
    - Beschrijf hoe je deze fout opgelost hebt ahv exacte commando's en/of wijzigingen aan configuratiebestanden
- Beschrijf ook het eindresultaat, de toestand van de VM op het einde van de sessie.
    - Wat heb je gerealiseerd en wat werkt eventueel nog niet?
    - Kopieer en plak een transcript van het uitvoeren van de acceptatietests.
    - Voeg een screenshot bij van wat je ziet als je toegang probeert te krijgen tot de service vanaf het fysieke systeem.
- Verwijder deze instructies uit je verslag.

## Verslag

### Fase 1: Network Access Layer
- Doel: Alle nodige netwerkadapters correct aansluiten
- 1: testen of alle interfaces verbonden zijn
    ````
    ip link
    ````
    Geeft enkel Loopback en Eth0, 
- 2: Kijken in Virtualbox of alle interfaces zijn aangesloten.
    Enkel Adapter 2 (Host-Only) is beschikbaar, geen NAT adapter
- 3: Dus EERST VM afsluiten om dan de eerste Netwerkadapter (NAT) te kunnen aansluiten (aanvinken)
- 4: Nu VM terug opstarten
- 5: Terug interfaces controleren
    ````
    ip link
    ````
    Nu zijn zijn er 3: Loopback, Eth0 en Eth1
- Network Access Layer is klaar, aangesloten NIC's paraat.

### Fase 2: Internet Layer
- DOEL: De juiste IP's voorzien en pingen mogelijk maken.
- 1: Controleer de Interfaces op hun IP's
    ````
    ip a
    ````
    Op eth1: geen ipv4 adres zichtbaar (MOET 192.168.56.8 zijn)
- 2: Interface Config controleren
    ````
    sudo cd /etc/sysconfig/
    ````
    Is niet toegankelijk
- 3: Probeer simpelweg eth1 op te starten:
    ````
    sudo ifup eth1
    ````
- 4: Nu weer eth1 controleren:
    ````
    ip a
    ````
    eth1 heeft nu het juiste ip (192.168.56.8/24)
- 5: Ping test via windows cmd naar VM
    ````
    ping 192.168.56.8
    ````
    Pingen lukt
- 6: Ping VM naar CMD
    ````
    ping 192.168.43.36
    ````
    Dit lukt ook!
- 7: Voor de zekerheid nog even Netwerkservice herstarten:
    ````
    sudo systemctl restart network
    ````

### Fase 3: Transport Layer
- Doel: ip kunnen bereiken via browser (Google Chrome)

- 1: Controleer of apache/httpd actief is
    ````
    systemctl status httpd.service
    ````
    WEL ENABLED
    NIET ACTIEF (FAILED)
- 2: probeer httpd te starten
    ````
    systemctl start httpd.service
    ````
    resultaat: error code

- 3: controleer de services, kijk of er iets van httpd bezig is
    ````
    systemctl status | grep httpd
    ````
    er is een lighttpd service 
- 4: controleer TCP poorten
    ````
    sudo ss -tlnp
    ````
    Poort 80 wordt gebruikt door lighttpd, geen teken van Apache
- 5: Controleer de lighttpd service
    ````
    systemctl status lighttpd
    ````
    Deze is enabled en actief
- 6: stop en disable Lighttpd
    ````
    sudo systemctl stop lighttpd
    sudo systemctl disable lighttpd
    ````
    De service is gestopt
- 7: probeer Apache(httpd) nog eens op te starten
    ````
    sudo systemctl start httpd.service
    ````
    Weer failed
- 8: in stap 4 zagen we dat er geen spoor was van httpd/apache voor tcp poort 80, dit moet nog opgelost worden.

- 9: Controleren of de httpd service door de firewall kan
    ````
    sudo firewall-cmd --list-all
    ````
    Https kan permanent door de firewall
- 10: Wanneer we Lighttpd terug starten en http door de firewall laten krigen we toch een webpagina te zien, Spijtig genoeg niet de juiste. Voorlopig neem ik aan dat het probleem nu in de applicatielaag zit. De Documentroot moet zeker bekeken worden.
HET IS ME DUIDELIJK DAT http door apache moet runnen, maar apache is obscuur in deze opgave.

- 11: is mariadb wel actief?
    ````
    [752380fv@fixme etc]$ sudo systemctl status mariadb
    ? mariadb.service - MariaDB 10.4.15 database server
   Loaded: loaded (/usr/lib/systemd/system/mariadb.service; disabled; vendor preset: disabled)
  Drop-In: /etc/systemd/system/mariadb.service.d
           +-migrated-from-my.cnf-settings.conf
   Active: inactive (dead)
     Docs: man:mysqld(8)
           https://mariadb.com/kb/en/library/systemd/

    ````
    NIET DUS
- 12: mariadb opstarten en enablen
    ````
    [752380fv@fixme etc]$ sudo systemctl enable mariadb
    [752380fv@fixme etc]$ sudo systemctl start mariadb
    [752380fv@fixme etc]$ sudo systemctl status mariadb
    ? mariadb.service - MariaDB 10.4.15 database server
   Loaded: loaded (/usr/lib/systemd/system/mariadb.service; enabled; vendor preset: disabled)
  Drop-In: /etc/systemd/system/mariadb.service.d
           +-migrated-from-my.cnf-settings.conf
   Active: active (running) since Fri 2020-10-30 14:49:45 UTC; 2s ago
     Docs: man:mysqld(8)
           https://mariadb.com/kb/en/library/systemd/
  Process: 2348 ExecStartPost=/bin/sh -c systemctl unset-environment _WSREP_START_POSITION (code=exited, status=0/SU>
  Process: 2304 ExecStartPre=/bin/sh -c [ ! -e /usr/bin/galera_recovery ] && VAR= ||   VAR=`cd /usr/bin/..; /usr/bin>
  Process: 2302 ExecStartPre=/bin/sh -c systemctl unset-environment _WSREP_START_POSITION (code=exited, status=0/SUC>
    Main PID: 2317 (mysqld)
   Status: "Taking your SQL requests now..."
    Tasks: 30 (limit: 5046)
   Memory: 113.0M
   CGroup: /system.slice/mariadb.service
           +-2317 /usr/sbin/mysqld
    ````
- 13: poortnummer Van SQL/Mariadb controleren
    ````
    sudo ss -tlnp
    State  Recv-Q Send-Q Local Address:Port  Peer Address:Port
    LISTEN 0      80         127.0.0.1:3306       0.0.0.0:*     users:(("mysqld",pid=2317,fd=22))
    ````

### Fase 4: Application Layer
- Doel: een succesvolle curl kunnen uitvoeren op het IP, idealiter de juiste pagina.

- 1 : Sinds er in Fase 3/stap 8 iets foutloopt met poortnummers, starten we met de apache syntax te valideren
    ````
    [752380fv@fixme etc]$ apachectl configtest
    AH00526: Syntax error on line 25 of /etc/httpd/conf/httpd.conf:
    DocumentRoot '/var/html' is not a directory, or is not readable
    ````
    Dus controleren we eens httpd.conf
    ````
    sudo vi /etc/httpd/conf/httpd.conf
    ````
    ````
      1 # Apache HTTP server - main configuration
      2 #
      3 # Ansible managed
      4
      5 ## General configuration
      6 ServerRoot /etc/httpd
      7 Listen 8080
    ````
    er hoort naar poort 80 te worden geluisterd, niet poort 8080
- 2: Verander 'Listen 8080' naar 'Listen 80'
- 3: probeer Apache(httpd) nog eens op te starten
    ````
    sudo systemctl start httpd.service
    ````
    Weer failed
- 4: kijkje nemen op lijn 25 van httpd.conf (apachectl syntax fout)
    ````
    sudo vi /etc/httpd/conf/httpd.conf
    ````
    geeft ons 
    ````
    DocumentRoot /var/html
    ````
- 5: Controleren wat er staat in var/html
    ````
     cd /var/html
     -bash: cd: /var/html: No such file or directory
    ````
    Directory /html/ bestaat dus niet!
- 6: Waar is de juiste documentroot dan?
    Ik probeer /var/www/ eens als documentroot
    ````
     sudo vi /etc/httpd/conf/httpd.conf

     [verander DocumentRoot]
     DocumentRoot /var/www
    ````
- 7: probeer httpd te starten
    ````
    sudo systemctl start httpd
    ````
    dit werkt!
    nu nog de status bekijken
    ````
    [752380fv@fixme var]$ sudo systemctl status httpd
    ? httpd.service - The Apache HTTP Server
   Loaded: loaded (/usr/lib/systemd/system/httpd.service; enabled; vendor preset: disabled)
  Drop-In: /usr/lib/systemd/system/httpd.service.d
           +-php-fpm.conf
   Active: active (running) since Fri 2020-10-30 15:14:49 UTC; 3s ago
     Docs: man:httpd.service(8)
    Main PID: 2501 (httpd)
   Status: "Started, listening on: port 443, port 80"
    Tasks: 213 (limit: 5046)
   Memory: 29.3M
   CGroup: /system.slice/httpd.service
           +-2501 /usr/sbin/httpd -DFOREGROUND
           +-2502 /usr/sbin/httpd -DFOREGROUND
           +-2503 /usr/sbin/httpd -DFOREGROUND
           +-2504 /usr/sbin/httpd -DFOREGROUND
           +-2505 /usr/sbin/httpd -DFOREGROUND
    ````
- 8: apache is nu toch actief
    In browser: testpagina van de Apache http server

- 9: Hebben we wel de juiste DocumentRoot gekozen?
    testen door 
    ````
     sudo vi /etc/httpd/conf/httpd.conf

     [verander DocumentRoot]
     DocumentRoot /var/www/html
     [Exit Vi]
     sudo systemctl reload httpd

     [752380fv@fixme var]$ apachectl configtest
    AH00558: httpd: Could not reliably determine the server's fully qualified domain name, using 127.0.1.1. Set the 'ServerName' directive globally to suppress this message
    Syntax OK

    ````
    
    Nu hebben we niet meer de apache testpagina maar verschijnt er "access denied"



### Fase 5: SELinux

- 1: SELinux booleans checken
    ik zie enkele interessante booleans
    ````
    httpd_can_network_connect_db --> off
    mysql_connect_http --> off
    ````
- 2: deze aanzetten
    ````
    sudo setsebool -P httpd_can_network_connect_db on
    sudo setsebool -P mysql_connect_http on
    ````
- 3 Is de context van de documentroot wel ok?
    ````
    cd /var/
    ls -Z
    [Resultaat]
     system_u:object_r:httpd_sys_content_t:s0 www
    ````
    Dit lijkt goed, voor de zekerheid even restoren & httpd reloaden
    ````
    sudo restorecon -R /var/www/
    sudo systemctl reload httpd
    ````
    maar nog steeds 'Access Denied" in browser

## Eindresultaat
````
[752380fv@fixme httpd]$ /usr/local/bin/acceptance.bats
 ? SELinux shoud be enforcing
 ? The firewall should be running
 ? I should have the correct IP address
 ? The Apache service should be running
 ? The correct website should be served
   (in test file /usr/local/bin/acceptance.bats, line 30)
     `[ "${checksum}" = "86e61b7c9a1baad76185db291b0643f1  -" ]' failed

5 tests, 1 failure

````

![browser](browser.PNG)

## Referenties

Lijst bronnen van nuttige informatie op die je gebruikt hebt voor het vervolledigen van deze labo-opdracht: boeken, handleidingen, websites, ...

- https://www.thegeekstuff.com/2017/07/chcon-command-examples/#:~:text=chcon%20stands%20for%20Change%20Context,security%20context%20of%20a%20file.
- mijn eigen cheat sheet
- syllabus